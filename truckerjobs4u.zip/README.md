# README

This README would normally document whatever steps are necessary to get the
application up and running.

Things you may want to cover:

* Ruby version

* System dependencies

* Configuration

* Database creation

* Database initialization

* How to run the test suite

* Services (job queues, cache servers, search engines, etc.)

* Deployment instructions

* ...



<video controls width="250" class="rounded-lg">
  <source src="<%= asset_path("Download.mp4") %>" type="video/mp4">
</video>

meta tags:

  * site

  * title
  * description
  * image
  
  * keywords
  * author

  **Image Information**

  Hero image size - desktop: 1920 x 1080 (400kb - max)
  Hero image size - mobile: 1080 x 680 (200 kb - max)

  Blog image size - both: 1080 x 680

  seo card image size: 1200 x 675
  file size: 100KB max

  blog article image size:


