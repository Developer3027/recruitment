class Newsletter < ApplicationRecord
end
