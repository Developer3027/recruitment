class ApplicationMailer < ActionMailer::Base
  default from: "truckerjobs4u.admin@trial-3yxj6ljj767ldo2r.mlsender.net"
  layout "mailer"
end
