# Built in helper for the admin dashboard
module AdminHelper
  # Pagy::Frontend navigation
  include Pagy::Frontend
end
