class PrivacyController < ApplicationController
  def index
  end
end
